# Workflow: The core object

Contract: `CORE-001`. Risk: Critical.

Rename the object throughout to whatever this product actually manages: campaign, lead,
event, service request, project, listing, client, or artist profile.

## Steps in scope

Create the central object, view it, edit it, archive or delete it, search and filter it,
export it, share it if allowed, and record audit history where needed.

## Actor and trigger

<FILL: which roles can perform each step.>

## Required behavior

- An authorized member can complete the full life cycle without leaving the product.
- Required fields are validated on the server, not only in the browser.
- The object is visible only to members of its organization.
- Only permitted roles can publish, archive, delete, export, or share.
- Invalid state transitions are rejected.
- Duplicate submission does not create two records.
- Deletion or archival follows <FILL: soft or hard delete rule> and is reversible where
  specified.
- List and search stay responsive at <FILL: expected record volume> with pagination bounds.

## Error and edge cases

Empty state, first record, very large record, concurrent edits by two users, deleting an
object referenced elsewhere, exporting more rows than the page limit, filtering with no
matches, retried create after a timeout.

## Data touched

The core table, its status field, related child records, audit history, export artifacts.

## Notifications and background work

<FILL: anything triggered on publish, share, or state change.>

## Evidence required

End to end recording of the full life cycle, role matrix results, cross tenant attempt
results, and query timing against seeded volume.
