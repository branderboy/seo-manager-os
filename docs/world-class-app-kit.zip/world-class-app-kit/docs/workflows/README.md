# Workflow specifications

Pillar 2 of `WORLD_CLASS_APP_THESIS.md`. A workflow document describes what the product does
and what must be true. A contract in `docs/contracts/` describes one delivery of it, with
constraints, proof, and verification.

Every workflow entry carries: actor, trigger, preconditions, happy path, error path, edge
cases, data created or edited or deleted or exported, permission requirements, third party
dependencies, notifications and background work, acceptance criteria, and the evidence
required to prove it works.

| File | Covers | Contract |
|---|---|---|
| authentication.md | Sign up, verification, login, logout, reset, sessions, deletion | AUTH-001 |
| user-roles.md | Organization creation, invites, roles, suspension, audit | ORG-001, ADMIN-001 |
| tenant-isolation.md | Data ownership and boundary enforcement | ORG-001 |
| core-workflow.md | The central object of the product | CORE-001 |
| billing.md | Trial, subscription, entitlement, webhook handling | BILLING-001 |
| integrations.md | Providers, OAuth, webhooks, retries, reconciliation | INTEGRATION-001 |

Operations workflows (error tracking, monitoring, backup, restore, deployment, rollback,
incident response) live in `docs/runbooks/` and are contracted under OBS-001.
