# Security Audit

Baseline: OWASP ASVS. Cross tenant and role boundary testing follows the OWASP authorization
regression testing approach. Run in a session or with an agent that did not implement the
code.

- Auditor:
- Date:
- Commit and environment:
- Contracts in scope:

## Verdicts

Each row gets one of: Confirmed secure, Confirmed finding, Insufficient evidence, or Not
applicable. Insufficient evidence is not a pass.

## Authentication

| # | Control | Verdict | Evidence |
|---|---|---|---|
| 1 | Registration only through approved flows | | |
| 2 | Email ownership verified where email is the identity | | |
| 3 | Passwords handled by a trusted system, never logged | | |
| 4 | Reset and verification tokens time limited and single use | | |
| 5 | Invalid, expired, tampered, and reused tokens fail safely | | |
| 6 | Session cookies or tokens configured securely | | |
| 7 | Sessions invalidated after password change or suspension | | |
| 8 | Errors do not reveal whether an account exists | | |
| 9 | Privileged accounts carry stronger safeguards | | |

## Authorization

| # | Control | Verdict | Evidence |
|---|---|---|---|
| 10 | Every protected action authorized on the server | | |
| 11 | Default deny where permission is not explicitly granted | | |
| 12 | Role checked, not only authentication | | |
| 13 | Record ownership and organization checked | | |
| 14 | Only authorized fields returned | | |
| 15 | Plan, entitlement, rate, and account status enforced | | |
| 16 | Direct API and ID manipulation attempts rejected | | |
| 17 | Cross tenant read, write, delete, export, and file access rejected | | |
| 18 | Admin actions audited | | |

## Input and output

| # | Control | Verdict | Evidence |
|---|---|---|---|
| 19 | All external input validated at the server boundary | | |
| 20 | Output encoding appropriate to the context | | |
| 21 | File type, size, and name validated server side | | |
| 22 | Error responses leak no internals or personal data | | |

## Secrets and configuration

| # | Control | Verdict | Evidence |
|---|---|---|---|
| 23 | No secret in the client bundle | | |
| 24 | No secret in repository history | | |
| 25 | Secrets stored in an approved secret system | | |
| 26 | Least privilege for keys, database access, and service accounts | | |

## Data protection

| # | Control | Verdict | Evidence |
|---|---|---|---|
| 27 | Data classification exists and matches what is actually stored | | |
| 28 | Retention and deletion behavior matches the stated policy | | |
| 29 | Personal data absent from logs, analytics, and support tooling | | |
| 30 | Backups protected to the same standard as live data | | |

## Integrations

| # | Control | Verdict | Evidence |
|---|---|---|---|
| 31 | Webhook signatures verified | | |
| 32 | Replay and duplicate delivery handled idempotently | | |
| 33 | Provider credentials server side only | | |
| 34 | Timeout, retry, and rate limit behavior defined | | |

## Findings

Use the finding format in `production-readiness-audit.md`: severity, workflow, expected,
observed, evidence, impact, remediation, verification required, owner.

## Release decision

- Any Confirmed finding at Critical or High is a release blocker.
- Decision: Approved / Conditionally ready / Not ready
- Human owner accepting any temporary risk, with reason and expiry date:
