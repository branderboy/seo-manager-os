# Accessibility Audit

Baseline: WCAG 2.2, W3C Recommendation of 5 October 2023, targeting Level AA where
reasonably applicable. https://www.w3.org/TR/WCAG22/

The rows below marked with a criterion number map to the nine criteria WCAG 2.2 added over
2.1. Those are the ones a product built before 2023 most often fails.

- Auditor:
- Date:
- Commit and environment:
- Screens and workflows reviewed:
- Assistive technology used:

## Method

Automated checks catch a minority of real problems. This review requires a keyboard only
pass and a screen reader aware pass over the critical workflows, plus a check at 200 percent
zoom and at a narrow mobile width.

## Keyboard and focus

| # | Check | Result | Notes |
|---|---|---|---|
| 1 | Every interactive control is reachable by keyboard | Pass / Fail | |
| 2 | Focus order is logical, and the focus indicator meets size and contrast (2.4.13) | Pass / Fail | |
| 3 | Focus is visible and not obscured by sticky headers, footers, or overlays (2.4.11) | Pass / Fail | |
| 4 | No keyboard trap in modals, menus, or embedded content | Pass / Fail | |
| 5 | Skip to content or equivalent exists on long pages | Pass / Fail | |

## Structure and naming

| # | Check | Result | Notes |
|---|---|---|---|
| 6 | Headings describe structure and are not chosen for size | Pass / Fail | |
| 7 | Every control has an accessible name that says what it does | Pass / Fail | |
| 8 | Images and icons have appropriate alternatives, decorative ones are hidden | Pass / Fail | |
| 9 | Form fields have persistent labels, not placeholder only | Pass / Fail | |
| 10 | Errors are announced and describe how to fix the problem | Pass / Fail | |
| 10b | Previously entered information is auto populated or selectable, not retyped (3.3.7) | Pass / Fail | |
| 10c | Help mechanisms appear in a consistent place across pages (3.2.6) | Pass / Fail | |

## Perception

| # | Check | Result | Notes |
|---|---|---|---|
| 11 | Text contrast meets AA | Pass / Fail | |
| 12 | Meaning is never carried by color alone | Pass / Fail | |
| 13 | Usable at 200 percent zoom without loss of content | Pass / Fail | |
| 14 | Usable at a narrow mobile width without horizontal scrolling | Pass / Fail | |
| 15 | Motion can be reduced or is not essential | Pass / Fail | |
| 15b | Dragging actions have a single pointer alternative (2.5.7) | Pass / Fail | |
| 15c | Targets meet the minimum size or spacing (2.5.8) | Pass / Fail | |

## Workflow level

| # | Check | Result | Notes |
|---|---|---|---|
| 16 | Sign in, verification, and password reset are completable by keyboard and screen reader | Pass / Fail | |
| 17 | Authentication needs no memory or transcription test with no alternative, and paste into password fields is allowed (3.3.8) | Pass / Fail | |
| 18 | Destructive actions are announced with their consequence before confirmation | Pass / Fail | |
| 19 | Status changes and background completions are announced, not only shown | Pass / Fail | |
| 20 | Data tables and lists are navigable and have programmatic headers | Pass / Fail | |

## Findings

| # | Severity | Screen or workflow | WCAG reference | Observed | Remediation | Owner |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  | |

## Decision

- Scope reviewed and scope deliberately excluded, with reason:
- Blocking issues:
- Accepted limitations, with the human owner who accepted each:
