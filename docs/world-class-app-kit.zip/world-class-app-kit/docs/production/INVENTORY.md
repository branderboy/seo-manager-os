# Application inventory

Phase 1 of the proof of concept to production path. Fill this in before adding features.
Cite file paths. Anything you cannot confirm is recorded as Unknown, not guessed.

- Inventoried by:
- Date:
- Commit:

## Users and roles

| Role | How it is assigned | What it can do that others cannot | Enforced where |
|---|---|---|---|
|  |  |  |  |

## Business workflows

| Workflow | Entry point | Status today | Risk class |
|---|---|---|---|
|  |  | Working / Partial / Broken / Unknown | Critical / High / Lower |

## Pages

| Page or route | Public or protected | Protection enforced server side | File |
|---|---|---|---|
|  |  | Yes / No / Unknown |  |

## APIs, server actions, jobs, webhooks

| Endpoint or job | Purpose | Auth check | Authorization check | Input validation | File |
|---|---|---|---|---|---|
|  |  |  |  |  |  |

## Data

| Table or bucket | Contains | Tenant key | Access policy | Migration tracked |
|---|---|---|---|---|
|  |  |  |  | Yes / No |

Data classifications present: 

## External services

| Provider | Used for | Credentials stored where | Environment tested |
|---|---|---|---|
|  |  |  | none / mock / sandbox / staging / live |

## Tests

| Suite or file | What it actually asserts | Would it fail if the behavior broke |
|---|---|---|
|  |  | Yes / No / Unknown |

## Environments and configuration

- Environments that exist:
- Required environment variables:
- Where secrets live:
- Deployment method:
- Rollback method:

## Known defects, limitations, and unverified claims

| Item | Impact | Evidence or lack of it | Owner |
|---|---|---|---|
|  |  |  |  |
