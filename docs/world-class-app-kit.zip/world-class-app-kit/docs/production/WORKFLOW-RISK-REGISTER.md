# Workflow risk register

Phase 2 of the proof of concept to production path. Every workflow from the inventory gets
a risk class. Critical workflows require a delivery contract, proof artifacts, and
independent verification before any production release.

- Classified by:
- Date:

## Critical

Anything involving customer data, money, access control, or irreversible effects.

| Workflow | Why critical | Contract ID | Contract status | Verified |
|---|---|---|---|---|
|  |  |  | None / Draft / Approved / Ready for verification / Verified | Yes / No |

## High priority

| Workflow | Why | Contract ID | Contract status | Verified |
|---|---|---|---|---|
|  |  |  |  | Yes / No |

## Lower priority

| Workflow | Note |
|---|---|
|  |  |

## Release rule

No production release while a Critical row shows an unverified contract, unless the human
owner has explicitly accepted it in writing as a known limitation with a stated reason.
