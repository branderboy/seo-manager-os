# Runbook: Deployment

Owner: <FILL: named human> | Last tested: <FILL: date>

## Before deploying

1. All relevant delivery contracts are Verified.
2. No critical or high release blocker remains, or the human owner has accepted it in
   writing with a reason.
3. Staging is healthy and the critical workflow evidence is current for this commit.
4. Migrations reviewed, with the rollback path in `rollback.md` confirmed.
5. Monitoring, alerts, logs, and dashboards are live and someone is watching.

## Deploy

- Command or pipeline: <FILL>
- Environment: production
- Strategy: <FILL: gradual, canary, or all at once, and why>
- Migration step and when it runs relative to the deploy: <FILL>
- Expected duration: <FILL>

## Watch

| Indicator | Where | Normal | Stop condition |
|---|---|---|---|
| Error rate |  |  |  |
| p95 latency |  |  |  |
| Failed jobs |  |  |  |
| Webhook processing |  |  |  |
| Auth success rate |  |  |  |

Monitoring window after release: <FILL: duration>. Named watcher: <FILL>.

## Smoke test

Run these against production immediately after deploy, with a real account:

1. Sign in.
2. Load the core object list.
3. Create and then delete a throwaway core object.
4. Trigger one integration path.
5. Confirm the health endpoint reports every dependency healthy.

## Record

Log the release, its outcome, anything abnormal, and follow up work in the release notes.
