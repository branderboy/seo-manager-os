# Runbook: Backup and restore

Owner: <FILL: named human> | Last successful restore test: <FILL: date>

A backup nobody has restored is not a backup. Restore once before launch and record the
date here.

## Backup policy

| What | Where | Frequency | Retention | Encrypted | Verified |
|---|---|---|---|---|---|
| Database |  |  |  | Yes / No | |
| File storage |  |  |  | Yes / No | |
| Configuration and secrets |  |  |  | Yes / No | |

## Objectives

- Recovery point objective, meaning acceptable data loss: <FILL>
- Recovery time objective, meaning acceptable downtime: <FILL>

## Restore procedure

1. Identify the target point in time and confirm the backup exists for it.
2. Restore into a separate environment first, never over live data.
3. Verify: row counts on core tables, one known record per tenant, authentication works, and
   file references resolve.
4. Confirm the tenant boundary still holds in the restored copy.
5. Decide with the human owner whether to promote the restore or export specific records.

## Restore test record

| Date | Backup used | Environment | Duration | Result | Notes |
|---|---|---|---|---|---|
|  |  |  |  |  |  |

## Known gaps

Anything not covered by backup, such as third party provider state, must be listed here so
nobody assumes it is recoverable.
