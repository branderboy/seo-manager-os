# Runbook: Rollback

Owner: <FILL: named human> | Last tested in staging: <FILL: date>

Rollback that has never been executed is a hypothesis. Test it in staging before it is
needed in production.

## Decide

Roll back when a stop condition from `deployment.md` is reached, when a critical workflow is
broken, or when data is at risk. Do not debug in production while users are affected if a
rollback is available.

## Application rollback

- Command or pipeline: <FILL>
- Previous known good build or commit: <FILL: where to find it>
- Expected duration: <FILL>
- Verification after rollback: run the smoke test in `deployment.md`.

## Database rollback

Application rollback does not undo a migration. For each risky migration record:

| Migration | Reversible | Down path | Data written since deploy | Correction approach |
|---|---|---|---|---|
|  | Yes / No |  |  |  |

Rules:

- Additive migrations first. Backfill separately from the deploy that reads the new column.
- Destructive migrations require human approval and a backup taken immediately before.
- If a rollback would strand data written after the deploy, correct forward instead and say
  so explicitly in the incident record.

## Side effects that cannot roll back

Emails sent, payments taken, webhooks acknowledged, files written, third party records
created. List the ones this release could produce and the reconciliation approach for each.

## After

Record what was rolled back, why, what data was affected, and which contract failed to catch
it. That last line is the one that prevents a repeat.
