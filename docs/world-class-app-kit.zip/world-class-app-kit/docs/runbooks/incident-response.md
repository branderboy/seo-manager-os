# Runbook: Incident response

Production owner: <FILL: named human> | Escalation contact: <FILL> | Last reviewed: <FILL>

## Severity

| Level | Meaning | Response |
|---|---|---|
| Critical | Unauthorized access, tenant data exposure, data loss, payment harm, exposed secrets, or the app is unusable | Immediate. Wake someone |
| High | An important workflow fails, security control bypassed, or major user harm under realistic conditions | Same day |
| Medium | Important defect with a workaround or limited blast radius | Next working day |
| Low | Usability, polish, minor correctness | Backlog |

## First fifteen minutes

1. Declare the incident and name one owner. One owner, not a group chat.
2. Answer: what failed, who is affected, when did it begin, what changed.
3. Check the most recent deploy. Recent change is the most likely cause.
4. Decide contain, roll back, or fix forward. Prefer contain and roll back.
5. If customer data may have been exposed, stop and treat it as a security incident:
   preserve logs before changing anything.

## Containment options

- Roll back the release. See `rollback.md`.
- Disable the affected route or feature flag.
- Pause the queue or the integration. See `integration-failure.md`.
- Revoke sessions or credentials if identity is involved.

## Communication

- Who tells customers, and at what severity: <FILL>
- Where status is posted: <FILL>
- Who decides on a breach notification, which is never the agent: <FILL>

## After

Within <FILL: number> days, write a short record: timeline, cause, what detected it, what
should have detected it, what the fix was, and which contract or test gets updated so the
same failure is caught next time. No blame on people. Blame on missing evidence.
