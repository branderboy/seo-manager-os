# Runbook: Integration failure

Owner: <FILL: named human> | Providers covered: <FILL>

## Detect

| Provider | Failure signal | Where it surfaces | Alert configured |
|---|---|---|---|
|  |  |  | Yes / No |

## Triage

1. Is the provider down, slow, rate limiting, or returning changed data? Check their status
   page before assuming a code defect.
2. Is the failure user visible, or queued and retrying?
3. Are side effects at risk of duplication, or of being lost?

## Contain

- Pause the queue or disable the trigger rather than letting retries pile up.
- Preserve failed payloads for reconciliation. Do not discard them to clear an alert.
- Communicate degraded behavior to users if the workflow is customer facing.

## Recover

1. Confirm the provider is healthy again.
2. Replay from the event ledger. Idempotency keys make this safe. If there is no ledger for
   this integration, that is a finding for INTEGRATION-001, not an improvisation now.
3. Reconcile against the provider as the source of truth and record what was corrected.
4. Verify no duplicate side effects were created: duplicate charges, duplicate emails,
   duplicate records.

## Escalate

Payments, identity, and anything touching customer data go to the human owner immediately.
An agent does not decide to refund, re send, or re issue.
