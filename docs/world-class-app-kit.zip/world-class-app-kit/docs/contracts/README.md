# Delivery contracts

One contract per workflow. One workflow per contract. Contracts are approved before
implementation and revised, not overwritten, when scope changes.

Naming: `AREA-###-short-workflow-name.md`

Every contract has the eighteen sections defined in section 4 of
`WORLD_CLASS_APP_THESIS.md`. The blank form is `_TEMPLATE.md`.

## Build order

Do not start the next critical contract until the current one is verified or explicitly
accepted by the human owner as a known limitation.

| ID | Workflow | Risk | Workflow spec | Status |
|---|---|---|---|---|
| AUTH-001 | Sign up, verification, login, logout, reset, sessions | Critical | authentication.md | Draft |
| ORG-001 | Organization creation, membership, roles, tenant isolation | Critical | tenant-isolation.md | Draft |
| CORE-001 | The central object end to end. Rename to the real object | Critical | core-workflow.md | Draft |
| ADMIN-001 | Invite, role change, suspension, restore, removal, audit | Critical | user-roles.md | Draft |
| FILES-001 | Secure upload, storage policy, authorized download, deletion | Critical | tenant-isolation.md | Draft |
| BILLING-001 | Subscription, entitlement, webhook handling | Critical | billing.md | Draft |
| INTEGRATION-001 | One external provider, failure and retry. Copy per provider | High | integrations.md | Draft |
| OBS-001 | Error tracking, logs, health checks, backup, rollback | Critical | runbooks/ | Draft |
| PERF-001 | Performance targets, scale bounds, unit economics | High | core-workflow.md | Draft |
| AUDIT-001 | Independent production readiness audit against all contracts | Critical | audits/ | Draft |

Drop FILES-001 or BILLING-001 if the product genuinely has no file handling or no payments.
Do not drop AUTH-001, ORG-001, OBS-001, or AUDIT-001.

## Status vocabulary

Draft, Approved, Ready for independent verification, Verified, Released. The implementing
agent can reach Ready for independent verification. Only a verifier who did not implement
the work can set Verified. Only the human owner can set Released.

## Filling in a draft

Every draft contains `<FILL: ...>` markers for facts that depend on the specific
application: provider names, table names, route paths, role rules, thresholds, and targets.
A contract is not approvable while a marker remains. Search for `<FILL:` before requesting
approval, and pull the answers from `PRODUCT_BRIEF.md` and `ARCHITECTURE_DECISIONS.md`
rather than inventing them here.
