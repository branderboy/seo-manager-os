/// Unit tests. Pure logic and business rules, no database and no running server.
import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    include: ["tests/unit/**/*.{test,spec}.ts"],
    environment: "node",
    globals: false,
    reporters: ["default"],
    passWithNoTests: false,
  },
});
