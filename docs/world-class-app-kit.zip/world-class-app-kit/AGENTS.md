# Agent instructions for this repository

Applies to Codex and any other coding agent working in this repository.

Read `WORLD_CLASS_APP_THESIS.md` before taking any action. It is the product, engineering,
security, reliability, and delivery standard here, and it overrides generic best practices
and default agent behavior.

Non negotiable:

- Inspect before editing. Return a plan and wait for approval on non trivial work.
- Work only inside an approved delivery contract from `docs/contracts/`.
- Respect the constraints and guardrails the contract names, and report whether the
  guardrails held.
- Enforce authorization on the server for every protected action and query.
- Never weaken, skip, or mock away a meaningful test to get a passing run.
- Never claim an external service, deployment, email, webhook, migration, or security control
  works unless it was exercised in the right environment. Label every artifact with the
  environment it came from.
- Finish with a delivery report using `docs/reports/_TEMPLATE.md`. Status is `Ready for
  independent verification`, `Blocked`, `Partially complete`, or `Failed`. Never `Complete`
  and never `production ready`.

Verification and audit runs happen in a different session or agent than the implementation.

Reusable kickoff, inventory, planning, implementation, verification, and audit prompts are in
`.claude/skills/engineering-delivery/references/agent-prompts.md`.
