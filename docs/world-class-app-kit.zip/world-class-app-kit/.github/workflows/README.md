# CI contract

The workflows call npm scripts by name rather than naming a test framework. That keeps the
pipeline stable while the tooling underneath changes, and it means CI works as soon as these
scripts exist in `package.json`.

Ready made script bodies for the default stack, Next.js with Prisma, Vitest, and Playwright,
are in `package.json.example` at the repo root. Merge that scripts block and CI runs. The
stack itself is described in `docs/stack/DEFAULT_STACK.md`.

| Script | What it must do | Used by |
|---|---|---|
| `lint` | Lint the codebase, non zero exit on error | ci.yml |
| `format:check` | Check formatting without writing | ci.yml |
| `typecheck` | Type check, non zero exit on error | ci.yml |
| `build` | Production build | ci.yml, e2e.yml, security.yml |
| `test:unit` | Unit tests only, no database needed | ci.yml |
| `test:integration` | Routes, database, storage, webhooks against a real test database | ci.yml |
| `test:authz` | Only the authorization and tenant isolation tests, so a failure is unmistakable | ci.yml |
| `test:e2e` | End to end critical workflows, starting the app itself | e2e.yml |
| `test:a11y` | Automated accessibility checks on key routes | e2e.yml |
| `db:migrate` | Apply all migrations to the database in `DATABASE_URL` | ci.yml, e2e.yml |
| `db:verify` | Prove the schema file matches the migration history, no drift | ci.yml |
| `db:seed:test` | Seed the Alpha and Beta fixtures in `tests/fixtures/tenants.md` | ci.yml, e2e.yml |

## Why `test:authz` is separate

A tenant isolation failure buried inside a large integration run gets skimmed past. Its own
job, with its own red mark, is the difference between a blocked release and a release that
went out anyway. Never add `continue-on-error` to that step.

## If a script does not exist yet

Delete the step, or point it at a script that fails loudly. Do not leave a step that exits
zero without doing anything. A green check that proves nothing is worse than no check,
because the release gate then reads it as evidence.

## Migrations and the missing down path

Prisma, Drizzle, and most modern migration tools have no automatic reverse. The CI job
proves migrations apply cleanly from empty and that the schema matches the history. It
cannot prove you can get back. That is why section 17 of every contract asks for the
rollback path in writing, and why a schema change whose plan is only "redeploy the previous
build" has not answered the question.

## Non Node stacks

Keep the job structure and replace the run lines. The structure is the part that matters:
static checks, then integration with a real database and seeded tenants, then a separate
authorization job, then migration up and down, then end to end, then dependency, secret, and
client bundle scanning.

## Client bundle check

`.github/scripts/check-client-bundle.sh` fails the build if a server only value reaches the
browser. List this project's variables in `.github/scripts/server-only-vars.txt`, and make
sure those variables are available to the workflow so their values can actually be compared.
The script fails rather than passes when it cannot find a build directory.
