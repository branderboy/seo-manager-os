# Claude Code instructions for this repository

Read `WORLD_CLASS_APP_THESIS.md` before taking any action. It is the product, engineering,
security, reliability, and delivery standard for this repository.

The same standard is installed as a skill at
`.claude/skills/engineering-delivery/SKILL.md`. Use it for all work here, including work
that looks small.

Before editing anything on a new task:

1. Confirm the work is justified in `PRODUCT_BRIEF.md`. If the capability is not there, say
   what is missing before writing code.
2. Confirm which delivery contract in `docs/contracts/` covers the work. If none does, draft
   one from `docs/contracts/_TEMPLATE.md` and request approval.
3. Inspect the codebase and report which files hold the product rules, authentication,
   authorization, data model, API layer, jobs, tests, and deployment configuration.
4. Return an implementation plan and wait for approval.

If this application is still an unaudited proof of concept and `docs/production/INVENTORY.md`
is empty, run the inventory first. Features stacked on an uninventoried proof of concept are
where rebuilds come from.

Do not report work as complete or production ready. Report `Ready for independent
verification`, `Blocked`, `Partially complete`, or `Failed`, with a delivery report in
`docs/reports/`. Only a verifier who did not implement the work can mark a contract
Verified, and only the human owner can release.

<!-- If this repository already has a CLAUDE.md, merge these instructions into it rather
than replacing the existing file. -->
