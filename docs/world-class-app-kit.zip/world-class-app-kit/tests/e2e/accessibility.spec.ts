/**
 * Automated accessibility checks on key routes, WCAG 2.2 A and AA tags.
 *
 * These catch a minority of real problems. The keyboard pass and the screen reader aware
 * pass in docs/audits/accessibility-audit.md are still required and are human owned.
 */
import { test, expect } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";
import { FIXTURES } from "../fixtures/seed";

const PUBLIC_ROUTES = ["/", "/sign-in", "/forgot-password"];
const AUTHENTICATED_ROUTES = ["/campaigns", "/settings"];

const TAGS = ["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"];

for (const route of PUBLIC_ROUTES) {
  test(`no automatically detectable violations on ${route}`, async ({ page }) => {
    await page.goto(route);
    const results = await new AxeBuilder({ page }).withTags(TAGS).analyze();
    expect(results.violations, JSON.stringify(results.violations, null, 2)).toEqual([]);
  });
}

test.describe("signed in", () => {
  test.beforeEach(async ({ page }) => {
    await page.goto("/sign-in");
    await page.getByLabel(/email/i).fill(FIXTURES.alpha.member);
    await page.getByLabel(/password/i).fill(FIXTURES.password);
    await page.getByRole("button", { name: /sign in/i }).click();
    await expect(page).not.toHaveURL(/sign-in/);
  });

  for (const route of AUTHENTICATED_ROUTES) {
    test(`no automatically detectable violations on ${route}`, async ({ page }) => {
      await page.goto(route);
      const results = await new AxeBuilder({ page }).withTags(TAGS).analyze();
      expect(results.violations, JSON.stringify(results.violations, null, 2)).toEqual([]);
    });
  }
});

test("keyboard focus is visible and reaches the primary action", async ({ page }) => {
  await page.goto("/sign-in");
  await page.keyboard.press("Tab");
  const focused = page.locator(":focus");
  await expect(focused).toBeVisible();
});
