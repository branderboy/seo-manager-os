/**
 * The end to end set from section 6 of WORLD_CLASS_APP_THESIS.md: sign in, the core object
 * life cycle, and a cross tenant attempt through the interface.
 *
 * These run against the built application. Selectors use accessible roles and names, which
 * doubles as a check that controls have accessible names at all.
 */
import { test, expect } from "@playwright/test";
import { FIXTURES } from "../fixtures/seed";

async function signIn(page: import("@playwright/test").Page, email: string) {
  await page.goto("/sign-in");
  await page.getByLabel(/email/i).fill(email);
  await page.getByLabel(/password/i).fill(FIXTURES.password);
  await page.getByRole("button", { name: /sign in/i }).click();
  await expect(page).not.toHaveURL(/sign-in/);
}

test.describe("authentication", () => {
  test("a verified user can sign in and sign out", async ({ page }) => {
    await signIn(page, FIXTURES.alpha.member);
    await page.getByRole("button", { name: /sign out|log out/i }).click();
    await expect(page).toHaveURL(/sign-in|^\/$/);
  });

  test("a protected page is not reachable without a session", async ({ page }) => {
    await page.goto("/campaigns");
    await expect(page).toHaveURL(/sign-in/);
  });
});

test.describe("core object life cycle", () => {
  test("create, view, and archive", async ({ page }) => {
    await signIn(page, FIXTURES.alpha.admin);

    await page.goto("/campaigns");
    await page.getByRole("link", { name: /new|create/i }).click();

    const title = `E2E campaign ${Date.now()}`;
    await page.getByLabel(/title|name/i).fill(title);
    await page.getByRole("button", { name: /save|create/i }).click();

    await expect(page.getByText(title)).toBeVisible();

    await page.getByRole("button", { name: /archive/i }).click();
    await page.getByRole("button", { name: /confirm|archive/i }).click();
    await expect(page.getByText(/archived/i)).toBeVisible();
  });
});

test.describe("tenant isolation through the interface", () => {
  test("a Beta user cannot open an Alpha record by URL", async ({ page }) => {
    await signIn(page, FIXTURES.beta.member);
    const response = await page.goto(`/campaigns/${FIXTURES.alpha.campaignId}`);
    const status = response?.status() ?? 0;

    if (status === 200) {
      // A rendered page is only acceptable if it is a denial, never the record itself.
      await expect(page.getByText("Alpha private campaign")).toHaveCount(0);
      await expect(page.getByText(/not found|no access|forbidden/i)).toBeVisible();
    } else {
      expect([401, 403, 404]).toContain(status);
    }
  });
});
