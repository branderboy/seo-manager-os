/**
 * The single place the tests know how your application signs a user in.
 *
 * It ships with the most common shape: POST credentials to a route handler that sets a
 * session cookie. If you use a hosted auth provider, replace the body of signIn and every
 * other test keeps working unchanged.
 *
 * Nothing else in the test suite should read cookies or call the auth routes directly.
 */
import { FIXTURES } from "../fixtures/seed";

export const BASE_URL = process.env.TEST_BASE_URL ?? "http://localhost:3000";

export type Session = {
  email: string;
  cookie: string;
};

/** Signs in a seeded fixture user and returns the cookie header to reuse on later requests. */
export async function signIn(email: string, password = FIXTURES.password): Promise<Session> {
  const response = await fetch(`${BASE_URL}/api/auth/sign-in`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password }),
    redirect: "manual",
  });

  const setCookie = response.headers.get("set-cookie");

  if (!response.ok || !setCookie) {
    throw new Error(
      `signIn failed for ${email} with status ${response.status}. ` +
        `If your auth route differs, this is the one function to change: tests/helpers/auth.ts`,
    );
  }

  return { email, cookie: setCookie.split(";")[0] };
}

/** Request as a signed in user. */
export function asUser(session: Session, path: string, init: RequestInit = {}) {
  return fetch(`${BASE_URL}${path}`, {
    ...init,
    headers: { "Content-Type": "application/json", cookie: session.cookie, ...(init.headers ?? {}) },
    redirect: "manual",
  });
}

/** Request with no session at all. */
export function asAnonymous(path: string, init: RequestInit = {}) {
  return fetch(`${BASE_URL}${path}`, {
    ...init,
    headers: { "Content-Type": "application/json", ...(init.headers ?? {}) },
    redirect: "manual",
  });
}

/** A rejection is any of these. A 200 with an empty list is not a rejection, it is a leak of shape. */
export const DENIED = [401, 403, 404];
