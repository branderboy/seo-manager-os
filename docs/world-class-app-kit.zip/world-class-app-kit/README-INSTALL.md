# World-Class App Kit

A repository operating system for building an application with AI coding agents: product
justification, architecture, security, testing, accessibility, reliability, performance,
economics, delivery contracts, independent verification, CI enforcement, and release.

The operating principle: build quickly with AI, accept slowly with evidence, operate
deliberately with automation, metrics, and clear ownership.

## What is in here

```
WORLD_CLASS_APP_THESIS.md            The authoritative standard. Everything follows it.
PRODUCT_BRIEF.md                     Pillar 1. Who it is for and why it should exist.
ARCHITECTURE_DECISIONS.md            Pillar 3. System shape, tenancy, scale, cost.
PRODUCTION_READINESS.md              The 37 line readiness review before real users.
CLAUDE.md                            Pointer loaded automatically by Claude Code.
AGENTS.md                            Pointer read by Codex and other agents.

docs/workflows/                      What the product does, per workflow.
docs/contracts/                      Ten starter contracts plus the blank 18 section form.
docs/reports/                        Delivery and independent verification reports.
docs/audits/                         Security, accessibility, and readiness audit checklists.
docs/runbooks/                       Deployment, rollback, incident, backup, integration failure.
docs/production/                     Proof of concept inventory and workflow risk register.

tests/                               unit, integration, e2e, helpers, fixtures.
                                     Ships with the tenant isolation, critical workflow,
                                     and accessibility specs already written.
prisma/schema.prisma                 Starter tenant scoped schema.
package.json.example                 The scripts CI calls, for the default stack.
.env.example                         Variables the tests and CI expect.
vitest.config.ts                     Unit tests.
vitest.integration.config.ts         Integration and authorization tests.
playwright.config.ts                 E2E, desktop and mobile, traces on failure.
docs/stack/DEFAULT_STACK.md          What the stack is and how to swap a piece.
.github/workflows/                   CI, E2E, and security pipelines, runnable as shipped.
.github/scripts/                     Client bundle secret check.

.claude/skills/engineering-delivery/  The standard as a Claude Code skill:
                                      16 reference modules and 4 templates.
```

## Install

1. Copy the contents of this folder into the root of your repository. Keep the structure,
   including the `.claude` and `.github` directories.
2. If the repository already has `CLAUDE.md`, `AGENTS.md`, or `.github/workflows/`, merge
   instead of overwriting.
3. Merge the scripts block from `package.json.example` into your `package.json`, and install
   the dev dependencies listed there. On the default stack, CI runs as shipped. On another
   stack, keep the job structure and replace the run lines.
4. Copy `.env.example` to `.env` and fill it in. List every server only variable in
   `.github/scripts/server-only-vars.txt` so the client bundle check can catch a leak.
5. Adjust the route paths at the top of `tests/integration/tenant-isolation.spec.ts` and the
   two e2e specs to match your application, then run `npm run db:migrate && npm run
   db:seed:test && npm run test:authz`.
6. Commit.
7. Open Claude Code and run `/skills` to confirm `engineering-delivery` is listed.

To use the skill across every project, also copy `engineering-delivery` to `~/.claude/skills/`.

## Order of work on an existing proof of concept

1. Inventory it. Run the inventory prompt in
   `.claude/skills/engineering-delivery/references/agent-prompts.md` and fill
   `docs/production/INVENTORY.md`. Do not add features first.
2. Classify every workflow in `docs/production/WORKFLOW-RISK-REGISTER.md`.
3. Write `PRODUCT_BRIEF.md` and `ARCHITECTURE_DECISIONS.md`. The tenant model and the scale
   assumptions are the two sections that decide whether this app survives customers.
4. Contract the critical workflows, starting with AUTH-001 and ORG-001.
5. Build, prove, verify, one contract at a time. A different session or person verifies.
6. Put the negative tests into CI as each contract is verified.
7. Run the security, accessibility, and readiness audits in `docs/audits/`.
8. Work `PRODUCTION_READINESS.md`. Any unchecked line means Not ready for production release.

## Order of work on a new application

`PRODUCT_BRIEF.md`, then `ARCHITECTURE_DECISIONS.md`, then AUTH-001, ORG-001, CORE-001, then
ADMIN-001, FILES-001, BILLING-001, INTEGRATION-001, OBS-001, PERF-001, then AUDIT-001. Small
vertical slices, never one giant prompt.

## Minimum launch bar for a first paid beta

Real authentication and verified access control. Server side authorization. Two tenant cross
access tests. Password reset and recovery testing. Proper secret handling. Backup and a
basic recovery plan. Error tracking and actionable logs. A staging environment. End to end
coverage of the main customer outcome. Mobile and keyboard usability review. Privacy policy,
terms, and data handling decisions. Manual human verification of the core workflow. A
rollback plan.

## The three rules that make the rest work

Contracts are approved before implementation. The agent that wrote the code never gets to be
the one that says it works. And whatever matters gets enforced by CI, because discipline
fades and automation does not.

## Fill markers

The starter contracts and the working documents contain `<FILL: ...>` markers for facts that
depend on your application: provider names, route paths, table names, role rules, targets,
and thresholds. A contract is not approvable while a marker remains. Search for `<FILL:`
before approving anything.

The CI files contain no markers. They call npm scripts by name and fail loudly rather than
passing silently, including the client bundle check, which exits non zero when it cannot
find a build to scan.
