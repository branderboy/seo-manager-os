# Product Brief

Pillar 1 of `WORLD_CLASS_APP_THESIS.md`. Write this before major implementation and keep it
current. A feature without a line in here is a feature nobody has justified.

- Product owner: <FILL: named human accountable for decisions>
- Last updated: <FILL: date>

## Target user

Who uses this first and why. One user, not a market.

## Painful current workflow

What they do today and what is broken, slow, expensive, confusing, or risky about it. What
they currently use instead of this product.

## Core value proposition

The meaningful result the product creates.

## Primary job to be done

When <FILL: situation>, the user wants to <FILL: motivation>, so they can <FILL: desired
outcome>.

## V1 scope

The smallest set of workflows that creates the core value.

| Workflow | User outcome | Why it is in V1 |
|---|---|---|
|  |  |  |

## Explicit non goals

Features, users, or markets intentionally excluded from V1. Being specific here is what
stops scope drift later.

## Success metrics

Pick the few that would actually change a decision. Examples: activation rate, weekly active
users, time saved, lead to sale conversion, campaign completion rate, retention, gross
margin, cost per successful workflow, support requests per active account.

| Metric | Definition | Baseline | Target | Measured where |
|---|---|---|---|---|
|  |  |  |  |  |

## Capability register

Every major capability needs all seven columns filled before it gets a contract.

| Capability | User problem | Target user | User outcome | Success metric | Non goal | Decision owner |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

## Assumptions to validate

What must be learned from real users before expanding the product.

| Assumption | How it gets tested | Status |
|---|---|---|
|  |  | Untested / Testing / Confirmed / Disproved |
