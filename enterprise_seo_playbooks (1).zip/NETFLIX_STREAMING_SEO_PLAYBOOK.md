# Netflix / Streaming Platform SEO Playbook

## Core Entity Model
Show -> Season -> Episode -> Actor -> Director -> Genre -> Collection

## SEO Objectives
- Own entertainment intent
- Capture title searches
- Capture actor searches
- Capture genre searches
- Build recommendation loops

## Page Types
/title/
/actor/
/director/
/genre/
/new-releases/
/top-10/
/similar-to/

## Internal Linking
Title -> Actor
Actor -> Title
Genre -> Title
Collection -> Genre

## KPIs
Indexed titles
Organic title traffic
Genre traffic
Watch-page conversions