# SaaS SEO Playbook

## Core Model
Problem -> Use Case -> Feature -> Integration -> Conversion

## Page Types
/features/
/use-cases/
/industries/
/alternatives/
/comparisons/
/integrations/
/templates/
/tools/

## BOFU Pages
Competitor alternatives
Comparison pages
Industry pages

## KPIs
Trials
Demos
Signups
Activation
Revenue