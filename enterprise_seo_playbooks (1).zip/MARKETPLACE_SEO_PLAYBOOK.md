# Marketplace SEO Playbook

## Core Entity Model
Category -> Subcategory -> Product -> Vendor -> Location

## Examples
Airbnb
Etsy
Thumbtack
Upwork

## Page Types
/category/
/subcategory/
/vendor/
/city/
/best-of/

## SEO Goal
Create millions of useful indexed pages.

## KPIs
Listings indexed
Organic leads
Bookings
Revenue