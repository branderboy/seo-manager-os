# Insurance SEO Playbook

## Entity Model
Insurance Type -> State -> City -> Coverage -> Quote

## Page Types
/auto-insurance/
/home-insurance/
/renters-insurance/
/state/
/city/

## Focus Areas
Authority
Trust
E-E-A-T
State-specific content

## KPIs
Quotes
Applications
Revenue
Organic visibility