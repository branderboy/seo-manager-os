# Sportsbook SEO Playbook

## Entity Model
Sport -> League -> Team -> Player -> Event -> Odds

## Page Types
/sportsbook/
/nfl/
/nba/
/odds/
/team/
/player/
/promo/

## Internal Linking
League -> Team
Team -> Player
Player -> Event
Event -> Odds

## KPIs
Betting signups
Deposits
Promo traffic
Organic sessions